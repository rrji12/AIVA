import time
import pyautogui

def control_media_player():
    print("Waiting for your input. Open your media player and focus on it.")

    while True:
        user_input = input("Enter 'play' or 'pause' (or 'exit' to quit): ").lower()

        if user_input == 'play':
            pyautogui.press('playpause')
            print("Media playback is resumed.")
        elif user_input == 'pause':
            pyautogui.press('playpause')
            print("Media playback is paused.")
        elif user_input == 'exit':
            print("Exiting the media player control.")
            break
        else:
            print("Invalid input. Enter 'play', 'pause', or 'exit'.")

# Example usage:
control_media_player()
