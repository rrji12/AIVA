import os
import pyautogui

def execute_command(command):
    if "open file" in command:
        file_name = extract_file_name(command)
        if file_name:
            file_path = search_file(file_name)
            if file_path:
                open_file_with_run(file_path)
            else:
                print(f"File '{file_name}' not found.")
        else:
            print("No file specified in the command.")
    elif "exit" in command:
        print("Exiting the script.")
        exit()
    else:
        print("Command not recognized.")

def extract_file_name(command):
    # Extract the file name from the command
    start_index = command.find("open file") + len("open file")
    return command[start_index:].strip()

def search_file(file_name):
    # Specify the root directory to start the search
    root_dir = 'C:\\'

    # Use os.walk to traverse through directories
    for foldername, subfolders, filenames in os.walk(root_dir):
        if file_name in filenames:
            return os.path.join(foldername, file_name)

    return None

def open_file_with_run(file_path):
    # Use pyautogui to simulate Win + R and paste the file path
    pyautogui.hotkey('winleft', 'r')  # Opens the Run dialog
    pyautogui.write(f'"{file_path}"')  # Enclose the file path in quotes
    pyautogui.press('enter')

# Example usage:
while True:
    user_input = input("Enter a command (or 'exit' to quit): ").lower()
    execute_command(user_input)
