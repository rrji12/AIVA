import os
import pyautogui

def search_and_open_file(file_name):
    # Specify the root directory to start the search (Desktop in this example)
    root_dir = 'C:\\Users\\priya\\OneDrive\\Desktop'

    # Use os.walk to traverse through directories
    for foldername, subfolders, filenames in os.walk(root_dir):
        if file_name in filenames:
            # Get the full path of the first matching file found
            file_path = os.path.join(foldername, file_name)

            # Print the file path
            print(f'The file "{file_name}" was found at: {file_path}')

            # Use pyautogui to simulate Win + R and paste the file path
            pyautogui.hotkey('winleft', 'r')  # Opens the Run dialog
            pyautogui.write(f'"{file_path}"')  # Enclose the file path in quotes
            pyautogui.press('enter')

            return

    # Print a message if the file is not found
    print(f'The file "{file_name}" was not found on the desktop.')

# Example usage:
file_name_to_search = 'mono.txt'
search_and_open_file(file_name_to_search)
