import os

def search_file_on_desktop(file_name):
    # Specify the root directory to start the search
    root_dir = 'C:\\Users\\priya\\OneDrive\\Desktop'

    # Use os.walk to traverse through directories
    for foldername, subfolders, filenames in os.walk(root_dir):
        if file_name in filenames:
            # Return the full path of the first matching file found
            return os.path.join(foldername, file_name)

    # Return None if the file is not found
    return None

# Example usage:
file_name_to_search = 'ticket to delhi.pdf'
file_path = search_file_on_desktop(file_name_to_search)

if file_path:
    print(f'The file "{file_name_to_search}" was found at: {file_path}')
else:
    print(f'The file "{file_name_to_search}" was not found on the desktop.')
