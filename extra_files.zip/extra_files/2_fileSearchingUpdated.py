import os
import pyautogui

def execute_command(command):
    if "open" in command and "file" in command:
        file_name = extract_file_name(command)
        if file_name:
            file_paths = search_files(file_name)
            if file_paths:
                if len(file_paths) == 1:
                    open_file_with_run(file_paths[0])
                else:
                    print(f"Multiple files found with the name '{file_name}'. Please enter the full name.")
            else:
                print(f"File '{file_name}' not found.")
        else:
            print("No file specified in the command.")
    elif "exit" in command:
        print("Exiting the script.")
        exit()
    else:
        print("Command not recognized.")

def extract_file_name(command):
    # Extract the file name from the command
    start_index = command.find("open") + len("open")
    return command[start_index:].strip()

def search_files(partial_name):
    # Specify the root directory to start the search
    root_dir = 'C:\\'
    
    # Use os.walk to traverse through directories
    matching_files = []
    for foldername, subfolders, filenames in os.walk(root_dir):
        matching_files.extend([os.path.join(foldername, file) for file in filenames if partial_name.lower() in file.lower()])

    return matching_files

def open_file_with_run(file_path):
    # Use pyautogui to simulate Win + R and paste the file path
    pyautogui.hotkey('winleft', 'r')  # Opens the Run dialog
    pyautogui.write(f'"{file_path}"')  # Enclose the file path in quotes
    pyautogui.press('enter')

# Example usage:
while True:
    user_input = input("Enter a command (or 'exit' to quit): ").lower()
    execute_command(user_input)
