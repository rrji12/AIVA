import pyaudio
import asyncio
import base64
import json
import websockets

from google.cloud import speech_v1p1beta1 as speech

google_credentials_path = 'C:\\Users\\priya\\OneDrive\\Desktop\\majorprojectspeechrecognition-f3c5a9b70b51.json'
language_code = 'en-US'

FRAMES_PER_BUFFER = 3200
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 16000

p = pyaudio.PyAudio()

# starts recording
stream = p.open(
   format=FORMAT,
   channels=CHANNELS,
   rate=RATE,
   input=True,
   frames_per_buffer=FRAMES_PER_BUFFER
)

# The Google Cloud Speech-to-Text API endpoint
URL = "wss://speech.googleapis.com/v1/operations:streamingRecognize"



async def send_receive():
    # Create a SpeechClient using your Google Cloud credentials
    client = speech.SpeechClient.from_service_account_json(google_credentials_path)

    _ws = None  # Define _ws outside the with block

    print(f'Connecting websocket to url ${URL}')
    async with websockets.connect(
        URL,
        ping_interval=5,
        ping_timeout=20
    ) as _ws:
        await asyncio.sleep(0.1)
        print("Receiving SessionBegins ...")
        session_begins = await _ws.recv()
        print(session_begins)

        async def send():
            while True:
                try:
                    data = stream.read(FRAMES_PER_BUFFER)
                    audio_content = base64.b64encode(data).decode("utf-8")
                    audio = speech.RecognitionAudio(content=audio_content)
                    config = speech.RecognitionConfig(
                        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
                        sample_rate_hertz=RATE,
                        language_code=language_code,
                    )
                    response = client.recognize(config=config, audio=audio)

                    for result in response.results:
                        print(result.alternatives[0].transcript)

                except Exception as e:
                    print(f"Error: {e}")
                    break
                await asyncio.sleep(0.01)

            return True

        async def receive():
            while True:
                try:
                    result_str = await _ws.recv()
                    print(json.loads(result_str)['text'])
                except websockets.exceptions.ConnectionClosedError as e:
                    print(e)
                    assert e.code == 4008
                    break
                except Exception as e:
                    assert False, "Not a websocket 4008 error"

        send_result, receive_result = await asyncio.gather(send(), receive())

asyncio.run(send_receive())
