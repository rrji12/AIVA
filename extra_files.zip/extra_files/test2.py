from whisper_mic1 import WhisperMic
import pyautogui

mic = WhisperMic(model="base", english=True)

print(mic.listen_loop())