# This code is for v1 of the openai package: pypi.org/project/openai
from openai import OpenAI
api_key = "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"  # Replace this with your actual API key
client = OpenAI(api_key=api_key)
response = client.chat.completions.create(
  model="gpt-3.5-turbo",
  messages=[
    {
      "role": "system",
      "content": "who are you, which version are you. how many api request i can make with you maximum per minute or day"
    },
    {
      "role": "user",
      "content": ""
    }
  ],
  temperature=1,
  max_tokens=256,
  top_p=1,
  frequency_penalty=0,
  presence_penalty=0
)

print(response.choices[0].message.content)


