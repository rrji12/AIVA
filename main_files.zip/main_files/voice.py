import speech_recognition as sr
from autocorrect import Speller

def recognize_speech():
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        print("Say something:")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source, timeout=5)

    try:
        text = recognizer.recognize_google(audio)
        print("You said:", text)
        return text
    except sr.UnknownValueError:
        print("Sorry, could not understand audio.")
        return None
    except sr.RequestError as e:
        print("Could not request results from Google Speech Recognition service; {0}".format(e))
        return None

def autocorrect_text(text):
    spell = Speller()
    corrected_text = spell(text)
    print("Autocorrected text:", corrected_text)
    return corrected_text

if __name__ == "__main__":
    recognized_text = recognize_speech()

    if recognized_text:
        corrected_text = autocorrect_text(recognized_text)
        # Now you can use the corrected_text for further processing or actions based on the user's input.
