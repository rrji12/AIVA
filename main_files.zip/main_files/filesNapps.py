import os
import pyautogui

class FileManager:
    def __init__(self):
        self.root_dir = 'C:\\'

    def search_file(self, file_name):
        for foldername, subfolders, filenames in os.walk(self.root_dir):
            if file_name in filenames or file_name in subfolders:
                return os.path.join(foldername, file_name)
        return None

    def open_target_with_run(self, target_path):
        pyautogui.hotkey('winleft', 'r')  # Opens the Run dialog
        pyautogui.write(f'"{target_path}"')  # Enclose the target path in quotes
        pyautogui.press('enter')

    def open_target(self, target_name):
        target_path = self.search_file(target_name)
        if target_path:
            self.open_target_with_run(target_path)
        else:
            print(f"Target '{target_name}' not found.")

    def launch_application(self, app_name):
        if "chrome" in app_name:
            os.system("start chrome")
        elif "notepad" in app_name:
            os.system("start notepad")
        # Add more conditions for other applications as needed
        else:
            print(f"Application '{app_name}' not recognized.")

    def execute_command(self, command):
        if "open" in command:
            target_name = self.extract_target_name(command)
            if target_name:
                self.open_target(target_name)
            else:
                print("No target specified in the command.")
        elif "launch" in command:
            app_name = self.extract_app_name(command)
            if app_name:
                self.launch_application(app_name)
            else:
                print("No application specified in the command.")
        elif "rename" in command:
            old_name, new_name = self.extract_rename_info(command)
            if old_name and new_name:
                self.rename_file(old_name, new_name)
            else:
                print("Invalid rename command.")
        elif "size" in command:
            file_name = self.extract_target_name(command)
            if file_name:
                self.show_file_size(file_name)
            else:
                print("No file specified for size command.")
        elif "delete" in command:
            file_name = self.extract_target_name(command)
            if file_name:
                self.delete_file(file_name)
            else:
                print("No file specified for delete command.")
        # elif "move" in command:
        #     source, destination = self.extract_move_info(command)
        #     if source and destination:
        #         self.move_file(source, destination)
        #     else:
        #         print("Invalid move command.")
        # elif "copy" in command:
        #     source, destination = self.extract_copy_info(command)
        #     if source and destination:
        #         self.copy_file(source, destination)
        #     else:
        #         print("Invalid copy command.")
        elif "exit" in command:
            print("Exiting the script.")
            exit()
        else:
            print("Command not recognized.")

    def extract_rename_info(self, command):
        start_index = command.find("rename") + len("rename")
        names = command[start_index:].split(" to ")
        return names[0].strip(), names[1].strip() if len(names) == 2 else (None, None)

    # def extract_move_info(self, command):
    #     # Extract source and destination from the command
    #     start_index = command.find("move") + len("move")
    #     info = command[start_index:].split(" to ")
    #     if len(info) == 2:
    #         print(info[0].strip(), info[1].strip())
    #         return info[0].strip(), info[1].strip()
    #     else:
    #         return None, None

    # def extract_copy_info(self, command):
    #     # Extract source and destination from the command
    #     start_index = command.find("copy") + len("copy")
    #     info = command[start_index:].split(" to ")
    #     if len(info) == 2:
    #         return info[0].strip(), info[1].strip()
    #     else:
    #         return None, None


    def show_file_size(self, file_name):
        file_path = self.search_file(file_name)
        try:
            if file_path:
                size = os.path.getsize(file_path)
                print(f"Size of '{file_name}': {size} bytes")
            else:
                print(f"File '{file_name}' not found.")
        except FileNotFoundError:
            print(f"File '{file_name}' not found.")

    def delete_file(self, file_name):
        file_path = self.search_file(file_name)
        try:
            if file_path:
                os.remove(file_path)
                print(f"File '{file_name}' deleted successfully.")
            else:
                print(f"File '{file_name}' not found.")
        except PermissionError:
            print(f"Permission denied to delete '{file_name}'.")

    # def move_file(self, source, destination):
    #     source_path = self.search_file(source)
    #     destination_path = os.path.join(os.path.expanduser('~'), destination, os.path.basename(source)) if destination.lower() in ['desktop', 'downloads', 'documents'] else os.path.join(os.path.expanduser('~'), destination, os.path.basename(source))
    #     try:
    #         if source_path:
    #             os.rename(source_path, destination_path)
    #             print(f"File '{os.path.basename(source)}' moved to '{destination_path}' successfully.")
    #         else:
    #             print(f"File '{source}' not found.")
    #     except PermissionError:
    #         print(f"Permission denied to move '{source}'.")

    # def copy_file(self, source, destination):
    #     source_path = self.search_file(source)
    #     destination_path = os.path.join(os.path.expanduser('~'), destination, os.path.basename(source)) if destination.lower() in ['desktop', 'downloads', 'documents'] else os.path.join(os.path.expanduser('~'), destination, os.path.basename(source))
    #     try:
    #         if source_path:
    #             with open(source_path, 'rb') as src, open(destination_path, 'wb') as dest:
    #                 dest.write(src.read())
    #             print(f"File '{os.path.basename(source)}' copied to '{destination_path}' successfully.")
    #         else:
    #             print(f"File '{source}' not found.")
    #     except PermissionError:
    #         print(f"Permission denied to copy '{source}'.")

    def rename_file(self, old_name, new_name):
        old_path = self.search_file(old_name)
        if old_path:
            new_path = os.path.join(os.path.dirname(old_path), new_name)
            try:
                os.rename(old_path, new_path)
                print(f"File '{old_name}' renamed to '{new_name}' successfully.")
            except PermissionError:
                print(f"Permission denied to rename '{old_name}'.")
        else:
            print(f"File '{old_name}' not found.")

    def extract_target_name(self, command):
        start_index = command.find(" ") + 1
        return command[start_index:].strip()

    def extract_app_name(self, command):
        start_index = command.find("launch") + len("launch")
        return command[start_index:].strip()

# Example usage:
file_manager = FileManager()
while True:
    user_input = input("Enter a command (or 'exit' to quit): ").lower()
    file_manager.execute_command(user_input)
