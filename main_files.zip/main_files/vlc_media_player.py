import pyautogui
import time

class VLCMediaPlayer:
    def __init__(self):
        pass  # Add any initialization logic if needed

    def play_pause(self):
        pyautogui.press('space')

    def skip_forward(self):
        pyautogui.hotkey('ctrl', 'right')

    def skip_backward(self):
        pyautogui.hotkey('ctrl', 'left')

# Example usage:
vlc_player = VLCMediaPlayer()

while True:
    user_input = input("Enter a command ('exit' to quit): ").lower()

    if user_input == 'exit':
        break

    time.sleep(4)  # 4-second delay before executing the command

    if user_input == 'play':
        vlc_player.play_pause()
    elif user_input == 'pause':
        vlc_player.play_pause()
    elif user_input == 'skip forward':
        vlc_player.skip_forward()
    elif user_input == 'skip backward':
        vlc_player.skip_backward()
    else:
        print("Command not recognized. Please enter 'play', 'pause', 'skip forward', 'skip backward', or 'exit'.")
