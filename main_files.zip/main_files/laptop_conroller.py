import ctypes
import time
import pyautogui

class LaptopController:
    def __init__(self):
        pass  # Add any initialization logic if needed

    def adjust_brightness(self, level):
        # Adjust brightness on Windows
        try:
            # Using ctypes and Windows API for brightness adjustment
            SC_MONITORPOWER = 0xF170
            HWND_BROADCAST = 0xFFFF
            WM_SYSCOMMAND = 0x0112
            MONITOR_ON = -1

            ctypes.windll.user32.SendMessageW(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, MONITOR_ON)
        except Exception as e:
            print(f"Error adjusting brightness: {e}")

    def adjust_volume(self, level):
        # Adjust volume on Windows (placeholder, actual method may vary)
        print(f"Adjusting volume to {level} on Windows.")

    def take_screenshot(self):
        # Take a screenshot on Windows
        try:
            pyautogui.hotkey('printscreen')  # Pressing the Print Screen key
            time.sleep(1)  # Wait for the screenshot to be taken
        except Exception as e:
            print(f"Error taking screenshot: {e}")

    def switch_tabs(self, direction):
        # Switching tabs using Alt+Tab on Windows
        try:
            if direction == 'forward':
                pyautogui.hotkey('alt', 'tab')
            elif direction == 'backward':
                pyautogui.hotkey('alt', 'shift', 'tab')
        except Exception as e:
            print(f"Error switching tabs: {e}")

    def switch_virtual_desktop(self, direction):
        # Switching virtual desktops using Windows key + Ctrl + Left/Right on Windows 10
        try:
            if direction == 'right':
                pyautogui.hotkey('win', 'ctrl', 'right')
            elif direction == 'left':
                pyautogui.hotkey('win', 'ctrl', 'left')
        except Exception as e:
            print(f"Error switching virtual desktops: {e}")

# Example usage:
laptop_controller = LaptopController()

while True:
    user_input = input("Enter a command ('exit' to quit): ").lower()

    if user_input == 'exit':
        break

    time.sleep(4)  # 4-second delay before executing the command

    if user_input.startswith('brightness'):
        level = int(user_input.split(' ')[1])
        laptop_controller.adjust_brightness(level)
    elif user_input.startswith('volume'):
        level = int(user_input.split(' ')[1])
        laptop_controller.adjust_volume(level)
    elif user_input == 'screenshot':
        laptop_controller.take_screenshot()
    elif user_input.startswith('switch tabs'):
        direction = user_input.split(' ')[-1]
        laptop_controller.switch_tabs(direction)
    elif user_input.startswith('switch desktop'):
        direction = user_input.split(' ')[-1]
        laptop_controller.switch_virtual_desktop(direction)
    else:
        print("Command not recognized. Please enter 'exit' to quit or provide a valid command.")
